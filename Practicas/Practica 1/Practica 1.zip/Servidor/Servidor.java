import java.net.*;
import java.io.*;
import java.util.Scanner;

public class Servidor {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        try {
            // Se establece la conexión con el cliente
            System.out.println("\n\nIngrese el puerto: ");
            int puerto = ent.nextInt();
            ServerSocket s = new ServerSocket(puerto);
            for (;;) {
                Socket cl = s.accept();
                System.out.println("Inicio de sesión exitoso");

                // Aqui se empieza a leer el TXT e impresion de base de datos
                Cargar bd = new Cargar();
                bd.cargar("bd2.txt");
                // Aqui ya se hizo todo el proceso de serialización.
                // Ahora se envia el archivo
                // Obtenemos los datos a enviar primero datos despues imagenes
                Cargar Numero = new Cargar();
                int num = (Numero.valor()) + 1;
                System.out.println("++++++++" + num);
                // Se inicializa el array
                File f[] = new File[num];
                f[0] = new File("Productos/serializado.txt");
                // Aqui se llena el array con los datos mediante string
                for (int i = 1; i < num; i++) {
                    f[i] = new File("Productos/Prod_" + i + ".jpg");
                    System.out.println(f[i]);
                }

                DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
                // Aqui se envía la longitud para el cliente reciba todos los archivos.
                dos.writeInt(num);
                dos.flush();
                for (int i = 0; i < num; i++) {
                    String archivo = f[i].getAbsolutePath();
                    String nombre = f[i].getName();
                    long tam = f[i].length();

                    // DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
                    DataInputStream dis = new DataInputStream(new FileInputStream(archivo));
                    dos.writeUTF(nombre);
                    dos.flush();
                    dos.writeLong(tam);
                    dos.flush();
                    byte[] b = new byte[1024];
                    long enviados = 0;
                    int porcentaje, n;

                    while (enviados < tam) {
                        n = dis.read(b);
                        dos.write(b, 0, n);
                        dos.flush();
                        enviados = enviados + n;
                        porcentaje = (int) (enviados * 100 / tam);
                        // System.out.println("El Catalogo de productos se esta enviando");
                    }

                    // dis.close();

                }
                System.out.println("\n\nCatalogo envido correctamente.");

                // PRIMERA PROPUESTA=LLENAR LA PRIMERA POSICIÓN DEL VECTOR CON LA BASE
                // SERIALIZADA
                // DESPUES MANDAR IMAGENES
                dos.close();
                // AQUI SE PUEDE RECIBIR EL ARCHIVO
                // DataInputStream envio = new DataInputStream(cl.getInputStream());
                // byte[] bt = new byte[1024];
                // String nom = envio.readUTF();
                // System.out.println("Hecho");
                // long tama = envio.readLong();
                // DataOutputStream envio2 = new DataOutputStream(new
                // FileOutputStream("bd2.txt"));
                // long recibidoss = 0;
                // int nu, percen;
                // while (recibidoss < tama) {
                // nu = envio.read(bt);
                // envio2.write(bt, 0, nu);
                // envio2.flush();
                // recibidoss = recibidoss + nu;
                // percen = (int) (recibidoss * 100 / tama);
                // }
                // System.out.println("Completado");
                // envio.close();
                // envio2.close();
                ///// SEGUNDO INTENTO
                // ServerSocket server;
                // Socket connection;

                // DataOutputStream output;
                // BufferedInputStream bis;
                // BufferedOutputStream bos;

                // byte[] receivedData;
                // int in;
                // String file;

                // try {
                // server = new ServerSocket(3013);
                // while (true) {
                // connection = server.accept();

                // receivedData = new byte[1024];
                // bis = new BufferedInputStream(connection.getInputStream());
                // DataInputStream dis = new DataInputStream(connection.getInputStream());

                // // recibimos el nombre del fichero
                // file = dis.readUTF();
                // file = file.substring(file.indexOf('/') + 1, file.length());

                // bos = new BufferedOutputStream(new FileOutputStream(file));
                // while ((in = bis.read(receivedData)) != -1) {
                // bos.write(receivedData, 0, in);
                // }
                // bos.close();
                // dis.close();
                // connection.close();
                // // se llama para deserealizar
                // Deserializar base = new Deserializar();
                // base.deserializar();
                // }
                // } catch (Exception e) {
                // System.err.println(e);
                // }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
