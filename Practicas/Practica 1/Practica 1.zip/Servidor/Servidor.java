import java.net.*;
import java.io.*;
import java.util.Scanner;

public class Servidor {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        try {
            // Se establece la conexión con el cliente
            System.out.println("\n\nIngrese el puerto: ");
            int puerto = ent.nextInt();
            ServerSocket s = new ServerSocket(puerto);
            for (;;) {
                Socket cl = s.accept();
                System.out.println("Inicio de sesión exitoso");

                // Aqui se empieza a leer el TXT e impresion de base de datos
                Cargar bd = new Cargar();
                bd.cargar("bd2.txt");
                // Aqui ya se hizo todo el proceso de serialización.
                // Ahora se envia el archivo
                // Obtenemos los datos a enviar primero datos despues imagenes
                Cargar Numero = new Cargar();
                int num = (Numero.valor()) + 1;
                System.out.println("++++++++" + num);
                // Se inicializa el array
                File f[] = new File[num];
                f[0] = new File("Productos/serializado.txt");
                // Aqui se llena el array con los datos mediante string
                for (int i = 1; i < num; i++) {
                    f[i] = new File("Productos/Prod_" + i + ".jpg");
                    System.out.println(f[i]);
                }

                DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
                // Aqui se envía la longitud para el cliente reciba todos los archivos.
                dos.writeInt(num);
                dos.flush();
                for (int i = 0; i < num; i++) {
                    String archivo = f[i].getAbsolutePath();
                    String nombre = f[i].getName();
                    long tam = f[i].length();

                    // DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
                    DataInputStream dis = new DataInputStream(new FileInputStream(archivo));
                    dos.writeUTF(nombre);
                    dos.flush();
                    dos.writeLong(tam);
                    dos.flush();
                    byte[] b = new byte[1024];
                    long enviados = 0;
                    int porcentaje, n;

                    while (enviados < tam) {
                        n = dis.read(b);
                        dos.write(b, 0, n);
                        dos.flush();
                        enviados = enviados + n;
                        porcentaje = (int) (enviados * 100 / tam);
                        // System.out.println("El Catalogo de productos se esta enviando");
                    }

                    dis.close();

                }
                System.out.println("\n\nCatalogo envido correctamente.");

                // PRIMERA PROPUESTA=LLENAR LA PRIMERA POSICIÓN DEL VECTOR CON LA BASE
                // SERIALIZADA
                // DESPUES MANDAR IMAGENES
                dos.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
