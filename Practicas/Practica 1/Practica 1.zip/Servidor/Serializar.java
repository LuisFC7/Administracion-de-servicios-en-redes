import java.io.Serializable;

public class Serializar implements Serializable {
    public String Id;
    public String nombre;
    public String precio;
    public String descripcion;
    public String stock;

    // constructor
    public Serializar(String Id, String nombre, String precio, String descripcion, String stock) {
        this.Id = Id;
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
        this.stock = stock;

    }

}
