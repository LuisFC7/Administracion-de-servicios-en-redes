import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Arrays;
import java.util.Scanner;

public class Deserializar {

    public void deserializar() {
        Objeto[] base = null;
        try (ObjectInputStream deserializado = new ObjectInputStream(new FileInputStream("serializado.txt"))) {
            base = (Objeto[]) deserializado.readObject();
            // System.out.println(base.toString());

            System.out.println("\nCatalogo de Productos");
            System.out.println("\nNúmero  Producto      Precio     Descripción    Existencia");
            for (int i = 0; i < base.length; i++) {
                System.out.println(base[i].Id + " " + base[i].nombre + " " + base[i].precio + " " + base[i].descripcion
                        + "  " + base[i].stock);
            }

            //////// AQUI SE ESTAN HACIENDO MODIFICACIONES PARA EL CARRITO, PRIMER PROTOTIPO

            ///// opcion para el menu guardar el valor de i en una variable auxiliar
            Scanner entrada = new Scanner(System.in);

            int TAM = 20;
            String caprecio[] = new String[TAM];
            String caproducto[] = new String[TAM];
            int ccantidad[] = new int[TAM];
            int aux = 0;
            // Esta variable es la principal del while
            int continuar = 1;
            System.out.println("\n\nBuen día, este es su carrito de compras.");
            while (continuar == 1) {

                System.out.println("\nEliga una opción");
                System.out.println("1. Comprar Producto");
                System.out.println("2. Remover Producto");
                System.out.println("3. Modificar Producto");
                System.out.println("4. Terminar Compra.");
                int opcion = entrada.nextInt();
                switch (opcion) {
                    case 1:
                        // Añadir al carrito
                        // la bandera es 1 para seguir comprando
                        int band = 1;
                        int i = aux;
                        while (band == 1) {

                            System.out.println("\n\nIngrese el número del producto");
                            int identi = entrada.nextInt();
                            System.out.println("Ingrese la cantidad del producto");
                            int cantidad = entrada.nextInt();

                            if (cantidad > Integer.parseInt(base[identi - 1].stock)) {
                                System.out.println("\nCantidad mayor a existencia.");
                                System.out.println("\n¿Desea seguir comprando?");
                                System.out.println("1. Si");
                                System.out.println("2. No");
                                band = entrada.nextInt();
                            } else {
                                caproducto[i] = base[identi - 1].nombre;
                                caprecio[i] = base[identi - 1].precio;
                                ccantidad[i] = cantidad;
                                // Operación para restas productos de la base de datos
                                base[identi - 1].stock = String
                                        .valueOf(Integer.parseInt(base[identi - 1].stock) - cantidad);
                                System.out.println(
                                        "\nSTOCK ACTUAL DE " + base[identi - 1].nombre + " :" + base[identi - 1].stock);
                                System.out.println("\nProducto agregado al carrito......");
                                i++;
                            }
                            System.out.println("Productos en el carrito: \n");
                            // Visualización de carrito
                            for (int j = 0; j < TAM; j++) {
                                if (caproducto[j] != null) {
                                    System.out.println(
                                            "Producto: " + caproducto[j] + " Precio: $" + caprecio[j] + " Cantidad: "
                                                    + ccantidad[j]);
                                }

                            }

                            System.out.println("\n¿Desea agregar otro producto?");
                            System.out.println("1. Si");
                            System.out.println("2. No");
                            band = entrada.nextInt();
                            if (band != 1)
                                aux = i;
                        }

                        break;

                    case 2:
                        // Aqui se elimina productos.
                        int band2 = 1;

                        while (band2 == 1) {

                            // ciclo para visualizar el carrito.
                            for (int j = 0; j < TAM; j++) {
                                if (caproducto[j] != null) {
                                    System.out.println(
                                            (j + 1) + ".  Producto: " + caproducto[j] + " Precio: $" + caprecio[j]
                                                    + " Cantidad: "
                                                    + ccantidad[j]);
                                }
                            }

                            System.out.println("\n\nIngrese el número del producto a eliminar");
                            int identi = entrada.nextInt();

                            // Ya se borro el elemento
                            caproducto[identi - 1] = null;
                            caprecio[identi - 1] = null;
                            ccantidad[identi - 1] = 0;

                            System.out.println("\nProducto eliminado del carrito\n");
                            for (int j = 0; j < TAM; j++) {
                                if (caproducto[j] != null) {
                                    System.out.println(
                                            (j + 1) + ".  Producto: " + caproducto[j] + " Precio: $" + caprecio[j]
                                                    + " Cantidad: "
                                                    + ccantidad[j]);
                                }
                            }

                            System.out.println("\n¿Desea eliminar otro producto?");
                            System.out.println("1. Si");
                            System.out.println("2. No");
                            band2 = entrada.nextInt();
                        }

                        break;

                    case 3:

                        break;

                    case 4:

                        break;

                    default:
                        break;
                }
            }

        } catch (ClassCastException e) {
        } catch (Exception e) {
        }

    }

}
