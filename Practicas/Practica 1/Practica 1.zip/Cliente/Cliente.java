import java.net.*;
import java.io.*;

public class Cliente {
    public static void main(String[] argsStrings) {

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("\n\nEscriba la dirección del servidor: ");
            String host = br.readLine();
            System.out.println("\n\nEscriba el puerto: ");
            int pto = Integer.parseInt(br.readLine());
            Socket cl = new Socket(host, pto);
            // Aqui se recibe el catalogo
            DataInputStream dis = new DataInputStream(cl.getInputStream());// para leer datos
            // aqui leemos la parte del array
            int num = dis.readInt();

            for (int i = 0; i < num; i++) {
                String nombre = dis.readUTF();
                // System.out.println("Catalogo Cargado");
                long tam = dis.readLong();

                DataOutputStream dos = new DataOutputStream(new FileOutputStream(nombre));
                long recibidos = 0;
                int n, porcentaje;

                while (recibidos < tam) {
                    int aux = (int) tam;
                    byte[] b = new byte[aux];
                    n = dis.read(b);
                    dos.write(b, 0, n);
                    dos.flush();
                    recibidos = recibidos + n;
                    porcentaje = (int) (recibidos * 100 / tam);
                    // System.out.println("Catalogo descargado");
                }
                dos.close();
            }

            System.out.println("Abriendo Catalogo de Productos........");
            // Aqui se comienza a deserializar la base de datos e impresión de base de
            // datos.
            Deserializar base = new Deserializar();
            base.deserializar();
            dis.close();
            cl.close();

        } catch (IOException e) {

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
