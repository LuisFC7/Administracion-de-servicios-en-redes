//Aquise crea el objeto y lo serializamos
public class Carrito {

    public String Id;
    public String nombre;
    public String precio;
    public String descripcion;
    public String cantidad;

    public Carrito(String Id, String nombre, String precio, String descripcion, String cantidad) {
        this.Id = Id;
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
    }

}