import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Scanner;

public class Operaciones {
    public void Comprar(Object[] catalogo) {
        // CODIGO FUNCIONANDO
        Scanner entrada = new Scanner(System.in);
        System.out.println("\n\nBuen día, este es su carrito de compras.");
        System.out.println("\nEliga una opción");
        System.out.println("1. Comprar Producto");
        System.out.println("2. Remover Producto");
        System.out.println("3. Modificar Producto");
        System.out.println("4. Terminar Compra.");
        int opcion = entrada.nextInt();

        // Objeto de tipo carrito para guardar las compras y generar tickets
        // Aqui se empiezan a hacer las operaciones
        switch (opcion) {
            case 1:
                // Añadir al carrito
                System.out.println("\n\nIngrese el número del producto");
                int identi = entrada.nextInt();
                System.out.println("Ingrese la cantidad del producto");
                int cantidad = entrada.nextInt();
                System.out.println(catalogo[0]);

                break;

            default:
                break;
        }
    }
}
