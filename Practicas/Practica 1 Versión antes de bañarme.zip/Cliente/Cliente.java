import java.net.*;
import java.io.*;

public class Cliente {
    public static void main(String[] argsStrings) {

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("\n\nEscriba la dirección del servidor: ");
            String host = br.readLine();
            System.out.println("\n\nEscriba el puerto: ");
            int pto = Integer.parseInt(br.readLine());
            Socket cl = new Socket(host, pto);
            // Aqui se recibe el catalogo
            DataInputStream dis = new DataInputStream(cl.getInputStream());// para leer datos
            // aqui leemos la parte del array
            int num = dis.readInt();

            for (int i = 0; i < num; i++) {
                String nombre = dis.readUTF();
                // System.out.println("Catalogo Cargado");
                long tam = dis.readLong();

                DataOutputStream dos = new DataOutputStream(new FileOutputStream(nombre));
                long recibidos = 0;
                int n, porcentaje;

                while (recibidos < tam) {
                    int aux = (int) tam;
                    byte[] b = new byte[aux];
                    n = dis.read(b);
                    dos.write(b, 0, n);
                    dos.flush();
                    recibidos = recibidos + n;
                    porcentaje = (int) (recibidos * 100 / tam);
                    // System.out.println("Catalogo descargado");
                }
                dos.close();
            }

            System.out.println("Abriendo Catalogo de Productos........");
            // Aqui se comienza a deserializar la base de datos e impresión de base de
            // datos.
            Deserializar base = new Deserializar();
            base.deserializar();
            dis.close();
            // // aqui enviar archivo base actualizado a servidor
            // // podria ir dentro de un try
            // File ultimo = new File("Bases/bd2.txt");
            // String ar = ultimo.getAbsolutePath();
            // String nom = ultimo.getName();
            // long tama = ultimo.length();

            // DataOutputStream envio = new DataOutputStream(cl.getOutputStream());
            // DataInputStream envio2 = new DataInputStream(new FileInputStream(ar));
            // envio.writeUTF(nom);
            // envio.flush();
            // envio.writeLong(tama);
            // envio.flush();
            // byte[] bt = new byte[1024];
            // long enviadoss = 0;
            // int percen, nu;

            // while (enviadoss < tama) {
            // nu = envio2.read(bt);
            // envio.write(bt, 0, nu);
            // envio.flush();
            // enviadoss = enviadoss + nu;
            // percen = (int) (enviadoss * 100 / tama);

            // }

            // System.out.println("Catalogo devuelto");
            // envio.close();
            // envio2.close();

            DataInputStream input;
            BufferedInputStream bis;
            BufferedOutputStream bos;
            int in;
            byte[] byteArray;
            final String filename = "Base/b2.txt";

            try {
                final File localFile = new File(filename);
                Socket client = new Socket(host, 3013);
                bis = new BufferedInputStream(new FileInputStream(localFile));
                bos = new BufferedOutputStream(client.getOutputStream());
                System.out.println("Hecho");
                // enviamos el nombre del archivo
                DataOutputStream dos = new DataOutputStream(client.getOutputStream());
                dos.writeUTF(localFile.getName());

                byteArray = new byte[1024];
                while ((in = bis.read(byteArray)) != -1) {
                    bos.write(byteArray, 0, in);
                }

                bis.close();
                bos.close();
                client.close();// aqui se modifico

            } catch (Exception e) {
                System.err.println(e);
            }

            // dis.close();
            cl.close();

        } catch (IOException e) {

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
