import java.io.Serializable;

//Aquise crea el objeto y lo serializamos
public class Objeto implements Serializable {

    public String Id;
    public String nombre;
    public String precio;
    public String descripcion;
    public String stock;

    public Objeto(String Id, String nombre, String precio, String descripcion, String stock) {
        this.Id = Id;
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
        this.stock = stock;
    }

    // @Override
    // public String toString() {
    // return this.Id + " " + this.nombre + " " + this.precio + " " +
    // this.descripcion + " " + this.stock;
    // }

    // public Objeto() {

    // }
    /////////// ANI
    // constructor
    // public Objeto(String Id, String nombre, String precio, String descripcion,
    // String stock) {
    // this.Id = Id;
    // this.nombre = nombre;
    // this.precio = precio;
    // this.descripcion = descripcion;
    // this.stock = stock;

    // }

    // public Objeto() {

    // }

    // public void crear(String[] Id, String[] nombre, String[] precio, String[]
    // descripcion, String[] stock, int num) {
    // // Aqui se crea array de objetos
    // Objeto objetos[] = new Objeto[num];

    // for (int i = 0; i < objetos.length; i++) {
    // objetos[i] = new Objeto(Id[i], nombre[i], precio[i], descripcion[i],
    // stock[i]);
    // }

    // }

    // }

}
