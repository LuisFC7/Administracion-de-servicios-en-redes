import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class Deserializar {
    public void deserializar() {
        Objeto[] base = null;
        try (ObjectInputStream deserializado = new ObjectInputStream(new FileInputStream("serializado.txt"))) {
            base = (Objeto[]) deserializado.readObject();
            System.out.println("\nCatalogo de Productos");
            System.out.println("\nNúmero  Producto      Precio     Descripción    Existencia");
            for (int i = 0; i < base.length; i++) {
                System.out.println(base[i].Id + " " + base[i].nombre + " " + base[i].precio + " " + base[i].descripcion
                        + "  " + base[i].stock);
                // caid[i] = String.valueOf(i + 1);
            }

        } catch (ClassCastException e) {

        } catch (Exception e) {

        }

    }

}
