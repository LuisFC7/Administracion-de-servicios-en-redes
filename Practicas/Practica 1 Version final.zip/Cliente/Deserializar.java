import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;
import javax.swing.text.Document;
import java.util.Date;

public class Deserializar {

    /**
     * 
     */
    public void deserializar() {
        Objeto[] base = null;
        try (ObjectInputStream deserializado = new ObjectInputStream(new FileInputStream("serializado.txt"))) {
            base = (Objeto[]) deserializado.readObject();
            // System.out.println(base.toString());
            int TAM = 20;
            String caid[] = new String[TAM];
            String auxiliar[] = new String[base.length];
            System.out.println("\nCatalogo de Productos");
            System.out.println("\nNúmero  Producto      Precio     Descripción    Existencia");
            for (int i = 0; i < base.length; i++) {
                System.out.println(base[i].Id + " " + base[i].nombre + " " + base[i].precio + " " + base[i].descripcion
                        + "  " + base[i].stock);
                // caid[i] = String.valueOf(i + 1);
                // Aqui se imprime la cantidad original de stock
                // copiar todos los stocks en un array
                auxiliar[i] = base[i].stock;
            }

            //////// AQUI SE ESTAN HACIENDO MODIFICACIONES PARA EL CARRITO, PRIMER PROTOTIPO

            ///// opcion para el menu guardar el valor de i en una variable auxiliar
            Scanner entrada = new Scanner(System.in);

            String caprecio[] = new String[TAM];

            String caproducto[] = new String[TAM];
            int ccantidad[] = new int[TAM];
            int aux = 0;
            // Esta variable es la principal del while
            int continuar = 1;
            System.out.println("\n\nBuen día, este es su carrito de compras.");
            while (continuar == 1) {

                System.out.println("\nEliga una opción");
                System.out.println("1. Comprar Producto");
                System.out.println("2. Remover Producto");
                System.out.println("3. Modificar Producto");
                System.out.println("4. Terminar Compra.");
                int opcion = entrada.nextInt();
                switch (opcion) {
                    case 1:
                        // Añadir al carrito
                        // la bandera es 1 para seguir comprando
                        int band = 1;
                        int i = aux;
                        while (band == 1) {

                            System.out.println("\n\nIngrese el número del producto");
                            int identi = entrada.nextInt();
                            System.out.println("Ingrese la cantidad del producto");
                            int cantidad = entrada.nextInt();

                            if (cantidad > Integer.parseInt(base[identi - 1].stock)) {
                                System.out.println("\nCantidad mayor a existencia.");
                                System.out.println("\n¿Desea seguir comprando?");
                                System.out.println("1. Si");
                                System.out.println("2. No");
                                band = entrada.nextInt();
                            } else {
                                caproducto[i] = base[identi - 1].nombre;
                                caprecio[i] = base[identi - 1].precio;
                                caid[i] = base[identi - 1].Id;
                                ccantidad[i] = cantidad;

                                // Operación para restas productos de la base de datos
                                base[identi - 1].stock = String
                                        .valueOf(Integer.parseInt(base[identi - 1].stock) - cantidad);

                                auxiliar[identi - 1] = base[identi - 1].stock;
                                System.out.println(
                                        "\nSTOCK ACTUAL DE " + base[identi - 1].nombre + " :" + base[identi - 1].stock);// Aqui
                                System.out.println("\nProducto agregado al carrito......");
                                i++;
                            }
                            System.out.println("Productos en el carrito: \n");
                            // Visualización de carrito
                            for (int j = 0; j < TAM; j++) {
                                if (caproducto[j] != null) {
                                    System.out.println(
                                            "Producto: " + caproducto[j] + " Precio: $" + caprecio[j] + " Cantidad: "
                                                    + ccantidad[j]);
                                }

                            }

                            System.out.println("\n¿Desea agregar otro producto?");
                            System.out.println("1. Si");
                            System.out.println("2. No");
                            band = entrada.nextInt();
                            if (band != 1)
                                aux = i;
                        }

                        break;

                    case 2:
                        // Aqui se elimina productos.
                        int band2 = 1;

                        while (band2 == 1) {

                            // ciclo para visualizar el carrito.
                            for (int j = 0; j < TAM; j++) {
                                if (caproducto[j] != null) {
                                    System.out.println(
                                            (j + 1) + ".  Producto: " + caproducto[j] + " Precio: $" + caprecio[j]
                                                    + " Cantidad: "
                                                    + ccantidad[j]);
                                }
                            }

                            System.out.println("\n\nIngrese el número del producto a eliminar");
                            int identi = entrada.nextInt();

                            // Ya se borro el elemento
                            caproducto[identi - 1] = null;
                            caprecio[identi - 1] = null;
                            ccantidad[identi - 1] = 0;
                            // Aqui se recupera la cantidad borrada
                            auxiliar[identi - 1] = base[identi - 1].stock;

                            System.out.println("\nProducto eliminado del carrito.......\n");
                            for (int j = 0; j < TAM; j++) {
                                if (caproducto[j] != null) {
                                    System.out.println(
                                            (j + 1) + ".  Producto: " + caproducto[j] + " Precio: $" + caprecio[j]
                                                    + " Cantidad: "
                                                    + ccantidad[j]);
                                }
                            }

                            System.out.println("\n¿Desea eliminar otro producto?");
                            System.out.println("1. Si");
                            System.out.println("2. No");
                            band2 = entrada.nextInt();
                            System.out.println("\n\n");
                        }

                        break;

                    case 3:
                        // Modificación del producto solo en cantidad.
                        int band3 = 1;
                        Scanner entrada2 = new Scanner(System.in);
                        // Para guardar datos

                        while (band3 == 1) {
                            // Impresión de carrito
                            for (int j = 0; j < TAM; j++) {
                                if (caproducto[j] != null) {
                                    System.out.println("Num:  " +
                                            (j + 1) + " ID: " + caid[j] + ".  Producto: " + caproducto[j]
                                            + " Precio: $" + caprecio[j]
                                            + " Cantidad: "
                                            + ccantidad[j]);

                                }

                            }

                            System.out.println("\nIngrese el numero del producto a modificar");
                            int num = entrada2.nextInt();
                            System.out.println("\nIngrese ID del producto a modificar");
                            int ifi = entrada2.nextInt();
                            System.out.println("\nIngrese la cantidad del producto a modificar");
                            int cantidad = entrada2.nextInt();

                            int real = Integer.parseInt(base[ifi - 1].stock) + ccantidad[num - 1];// Total de stock en

                            if (cantidad > real) {
                                System.out.println("\nCantidad mayor a existencia.");
                                System.out.println("\n¿Desea modificar otro producto?");
                                System.out.println("1. Si");
                                System.out.println("2. No");
                                band3 = entrada2.nextInt();
                            } else {
                                // Operación para restas productos de la base de datos
                                // base[ifi - 1].stock = String
                                // .valueOf(Integer.parseInt(base[ifi - 1].stock)
                                // - cantidad);
                                base[ifi - 1].stock = String.valueOf(real - cantidad);
                                ccantidad[num - 1] = cantidad;

                                System.out.println(
                                        "\nSTOCK ACTUAL DE " + base[ifi - 1].nombre + " :" + base[ifi - 1].stock);
                                System.out.println("Producto agregado al carrito......");
                                auxiliar[ifi - 1] = base[ifi - 1].stock;

                            }
                            System.out.println("Productos en el carrito: \n");
                            // Visualización de carrito
                            for (int j = 0; j < TAM; j++) {
                                if (caproducto[j] != null) {
                                    System.out.println(
                                            "Producto: " + caproducto[j] + " Precio: $" + caprecio[j] + " Cantidad: "
                                                    + ccantidad[j]);
                                }

                            }

                            System.out.println("\n¿Desea modificar otro producto?");
                            System.out.println("1. Si");
                            System.out.println("2. No");
                            band3 = entrada2.nextInt();
                            System.out.println("\n\n");

                        }

                        break;

                    case 4:
                        // Aqui se empieza a escribir en un txt para pasar al pdf
                        // imprimir fecha, hora, total y subtotal
                        float costos[] = new float[TAM];
                        float costoT = 0;

                        System.out.println("\n\n\nTICKET DE COMPRA.");
                        for (int j = 0; j < TAM; j++) {
                            if (caproducto[j] != null) {
                                // System.out.println(
                                // "Producto: " + caproducto[j] + " Precio: $" + caprecio[j] + " Cantidad: "
                                // + ccantidad[j]);
                                // Operación de cantidades y precio por producto
                                costos[j] = (Float.valueOf(caprecio[j])) * ccantidad[j];
                                costoT = costoT + costos[j];
                                System.out.println("Producto: " + caproducto[j] + "Cantidad: " + ccantidad[j]
                                        + "Costo Unitario: " + caprecio[j] + "Subtotal:  " + costos[j]);
                            }
                        }
                        System.out.println("Total a pagar: " + costoT);
                        Date date = new Date();
                        System.out.println(date + "\n\n\n");

                        // Comienzan operaciones de ticket

                        // Aqui se serializa nuevamente la base de datos
                        // Creamos el objeto para serializar
                        Objeto actualizado[] = new Objeto[base.length];
                        for (int m = 0; m < actualizado.length; m++) {
                            actualizado[m] = new Objeto(base[m].Id, base[m].nombre, base[m].precio, base[m].descripcion,
                                    base[m].stock);
                        }

                        try {
                            ObjectOutputStream serializado = new ObjectOutputStream(
                                    new FileOutputStream("Base/b2.txt"));
                            serializado.writeObject(actualizado);
                            serializado.close();

                            System.out.println("\nCatalogo de Productos");
                            System.out.println("\nNúmero  Producto      Precio     Descripción    Existencia");
                            for (int d = 0; d < base.length; d++) {
                                System.out.println(base[d].Id + " " + base[d].nombre + " " + base[d].precio + " "
                                        + base[d].descripcion
                                        + "  " + auxiliar[d]);
                                // caid[i] = String.valueOf(i + 1);
                            }

                            // IMPRESIÓN DE TICKET
                            PrintWriter writer = new PrintWriter("ticket.txt", "UTF-8");

                            int cont = 0;
                            for (int h = 0; h < TAM; h++) {
                                if (caproducto[h] != null) {
                                    cont++;
                                }
                            }
                            System.out.println("\n\n\nTICKET DE COMPRA.");
                            for (int j = 0; j < cont; j++) {
                                if (caproducto[j] != null) {
                                    System.out.println(
                                            "Producto: " + caproducto[j] + " Precio: $" + caprecio[j] + " Cantidad: "
                                                    + ccantidad[j]);

                                    // Operación de cantidades y precio por producto
                                    costos[j] = (Float.valueOf(caprecio[j])) * ccantidad[j];
                                    costoT = costoT + costos[j];

                                }

                                writer.println("Producto: " + caproducto[j] + " Cantidad: " + ccantidad[j]
                                        + " Costo Unitario: $" + caprecio[j] + " Subtotal: $" + costos[j]);
                            }

                            writer.println("Total a pagar: $" + costoT);
                            writer.println("Gracias vuelva pronto....");
                            writer.println(date);
                            writer.close();
                            // AQUI TERMINA IMPRESIÓN DEL TICKET

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        continuar = 2;
                        break;

                    default:
                        break;
                }
            }

        } catch (ClassCastException e) {
        } catch (Exception e) {
        }

    }

}
